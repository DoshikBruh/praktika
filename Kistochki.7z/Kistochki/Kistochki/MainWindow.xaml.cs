﻿using System.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kistochki
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            
        }


        Tipa tipa = new Tipa();
        task1 task1 = new task1();
        task2 task2 = new task2();
        task3 task3 = new task3();
        private void Form2_Click(object sender, RoutedEventArgs e)
        {

            tipa.Show();
           
        }

        private void Form1_Click(object sender, RoutedEventArgs e)
        {

            task1.Show();
        
        }

        private void Form3_Click(object sender, RoutedEventArgs e)
        {

            task2.Show();
         
        }
        private void Form4_Click(object sender, RoutedEventArgs e)
        {

            task3.Show();
      
        }


    }

}
